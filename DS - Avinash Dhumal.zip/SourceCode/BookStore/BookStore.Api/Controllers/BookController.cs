﻿using BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;
using BookStore.Application.Features.Book.Queries.GetAllBooksQuery;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Api.Controllers;

[Route("api/[Controller]")]
[ApiController]
public class BookController : ControllerBase
{
    private readonly IMediator _mediator;

    public BookController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpGet("searchbook")]
    public async Task<ActionResult<BookDto>> Get(string? title, string? author, string? publisher)
    {
        var bookDetails = await _mediator.Send(new GetBookDetailsQuery(title, author, publisher));
        _mediator.Send(new SaveSearchQueryCommand ()
        {
            Title = title,
            Author = author,
            Publisher = publisher,
            HasFound = bookDetails.Count > 0 ? true : false,
            CatalogURL = string.Empty,
            CustomerId = 1 //to be taken based on login id
        }) ;
        return Ok(bookDetails);
    }
}
