﻿using BookStore.Application.Contracts.PublisherCatalogService;
using BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;
using BookStore.Application.Features.Book.Queries.GetAllBooksQuery;
using BookStore.Application.Features.Publisher.Queries.GetAllPublishers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Api.Controllers;

[Route("api/[Controller]")]
[ApiController]
public class PublisherCatalogController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IPublisherCatalogService _publisherCatalogService;

    public PublisherCatalogController(IMediator mediator, IPublisherCatalogService publisherCatalogService)
    {
        _mediator = mediator;
        _publisherCatalogService = publisherCatalogService;
    }

    [HttpGet("getpublishercatalog")]
    public async Task<ActionResult<BookDto>> Get(string? title, string? author, string publisher)
    {
        var publishers = await _mediator.Send(new GetPublishersQuery(publisher));
        var bookData = await _publisherCatalogService.GetPublisherCatalogByTitleOrAuthor(title, author, publishers.CatalogURL);

#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
        _mediator.Send(new SaveSearchQueryCommand()
        {
            Title = title,
            Author = author,
            Publisher = publisher,
            HasFound = false,
            CatalogURL = publishers.CatalogURL,
            CustomerId = 1 //to be taken based on login id
        });
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed

        return Ok(bookData);
    }
}
