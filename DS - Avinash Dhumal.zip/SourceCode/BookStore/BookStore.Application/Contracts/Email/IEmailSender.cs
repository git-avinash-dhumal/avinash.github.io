﻿using BookStore.Application.Features.Book.Queries.GetAllBooksQuery;
using BookStore.Application.Models.Email;

namespace BookStore.Application.Contracts.Email;

public interface IEmailSender
{
    Task<bool> SendEmail(EmailMessage email);
}
