﻿using BookStore.Domain;

namespace BookStore.Application.Contracts.Persistence;

public interface IBookRepository : IGenericRepository<Book>
{
    Task<List<Book>> GetAsync(string title, string author, string publisher);
}


