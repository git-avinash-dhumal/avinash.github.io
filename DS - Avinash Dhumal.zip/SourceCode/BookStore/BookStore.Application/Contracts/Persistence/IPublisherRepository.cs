﻿using BookStore.Application.Contracts.Persistence;
using BookStore.Application.Features.Publisher.Queries.GetAllPublishers;
using BookStore.Domain;

public interface IPublisherRepository : IGenericRepository<Publisher>
{
    Task<bool> IsPublisherUnique(string name);
    Task<Publisher> GetPublisherCatalogDetails(string publisher);
}