﻿using BookStore.Domain;

namespace BookStore.Application.Contracts.Persistence;

public interface ISearchQueryRepository : IGenericRepository<SearchQuery>
{
}
