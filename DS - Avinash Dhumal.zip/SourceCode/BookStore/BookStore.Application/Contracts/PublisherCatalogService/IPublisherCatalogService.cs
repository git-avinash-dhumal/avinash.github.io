﻿namespace BookStore.Application.Contracts.PublisherCatalogService;

public interface IPublisherCatalogService
{
    Task<string> GetPublisherCatalogByTitleOrAuthor(string title, string author, string catalogURL);
}
