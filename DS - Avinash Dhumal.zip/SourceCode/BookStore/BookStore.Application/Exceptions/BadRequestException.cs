﻿using FluentValidation.Results;

namespace BookStore.Application.Exceptions;

public class BadRequestException : Exception
{
    public BadRequestException(string message, Task<ValidationResult> validationResult) : base(message)
    {

    }


    public BadRequestException(string message, ValidationResult validationResult) : base(message)
    {
        ValidationErrors = validationResult.ToDictionary();
    }

    public IDictionary<string, string[]> ValidationErrors { get; set; }
}
