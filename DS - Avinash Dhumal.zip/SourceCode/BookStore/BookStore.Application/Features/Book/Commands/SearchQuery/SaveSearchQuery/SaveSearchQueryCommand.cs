﻿using MediatR;

namespace BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;

public class SaveSearchQueryCommand: IRequest<Unit>
{
    public int CustomerId { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public string Publisher { get; set; }
    public bool HasFound { get; set; }
    public string CatalogURL { get; set; }
    public DateTime QueryDate { get; set; }
}
