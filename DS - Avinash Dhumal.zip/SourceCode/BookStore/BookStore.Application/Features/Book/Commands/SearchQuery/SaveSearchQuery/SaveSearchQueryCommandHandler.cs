﻿using AutoMapper;
using BookStore.Application.Contracts.Persistence;
using BookStore.Application.Exceptions;
using MediatR;

namespace BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;

public class SaveSearchQueryCommandHandler : IRequestHandler<SaveSearchQueryCommand, Unit>
{
    private readonly IMapper _mapper;
    private readonly ISearchQueryRepository _searchQueryRepository;

    public SaveSearchQueryCommandHandler(IMapper mapper, ISearchQueryRepository searchQueryRepository)
    {
        _mapper = mapper;
        _searchQueryRepository = searchQueryRepository;
    }

    public Task<Unit> Handle(SaveSearchQueryCommand request, CancellationToken cancellationToken)
    {
        // Validate incoming data
        var validator = new SaveSearchQueryCommandValidator();
        var validationResult = validator.ValidateAsync(request);

        if (validationResult.Result.Errors.Any())
            throw new BadRequestException("Invalid Search request", validationResult);

        // convert to domain entity object
        var searchQuery = _mapper.Map<Domain.SearchQuery>(request);

        searchQuery.QueryDate = DateTime.Now;

        // add to database
        _searchQueryRepository.CreateAsync(searchQuery);

        return null;
    }
}
