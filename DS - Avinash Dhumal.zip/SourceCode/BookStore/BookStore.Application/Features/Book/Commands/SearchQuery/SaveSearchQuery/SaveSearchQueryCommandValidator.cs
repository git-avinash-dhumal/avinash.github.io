﻿using FluentValidation;

namespace BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;

public class SaveSearchQueryCommandValidator: AbstractValidator<SaveSearchQueryCommand>
{
    public SaveSearchQueryCommandValidator()
    {
        RuleFor(x => x)
            .Must(HasAtleastTitleOrAuthorOrPublisher)
            .WithMessage("Either Title, Author or Publisher are required");
    }

    private bool HasAtleastTitleOrAuthorOrPublisher(SaveSearchQueryCommand arg)
    {
        return !string.IsNullOrEmpty(arg.Title) || !string.IsNullOrEmpty(arg.Author) || !string.IsNullOrEmpty(arg.Publisher);
    }
}
