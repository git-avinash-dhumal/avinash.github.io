﻿using FluentValidation;

namespace BookStore.Application.Features.Book.Queries.GetAllBooksQuery;

public class GetBookDetailQueryCommandValidator : AbstractValidator<BookDto>
{
    public GetBookDetailQueryCommandValidator()
    {
        RuleFor(x => x)
            .Must(HasAtleastTitleOrAuthorOrPublisher)
            .WithMessage("Either Title, Author or Publisher are required");
    }

    private bool HasAtleastTitleOrAuthorOrPublisher(BookDto arg)
    {
        return !string.IsNullOrEmpty(arg.Title) || !string.IsNullOrEmpty(arg.Author) || !string.IsNullOrEmpty(arg.Publisher.PublisherName);
    }
}
