﻿using MediatR;

namespace BookStore.Application.Features.Book.Queries.GetAllBooksQuery
{
    public record GetBookDetailsQuery(string title, string author, string publisher) : IRequest<List<BookDto>>;
}
