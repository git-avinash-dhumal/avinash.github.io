﻿using AutoMapper;
using BookStore.Application.Contracts.Logging;
using BookStore.Application.Contracts.Persistence;
using BookStore.Application.Exceptions;
using BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;
using MediatR;

namespace BookStore.Application.Features.Book.Queries.GetAllBooksQuery;

public class GetBookDetailQueryHandler : IRequestHandler<GetBookDetailsQuery, List<BookDto>>
{
    private readonly IMapper _mapper;
    private readonly IBookRepository _bookRepository;
    private readonly IAppLogger<GetBookDetailQueryHandler> _logger;

    public GetBookDetailQueryHandler(IMapper mapper, IBookRepository bookRepositoryy, IAppLogger<GetBookDetailQueryHandler> logger)
    {
        _mapper = mapper;
        _bookRepository = bookRepositoryy;
        _logger = logger;
    }

    public async Task<List<BookDto>> Handle(GetBookDetailsQuery request, CancellationToken cancellationToken)
    {
        // 
        // Validate incoming data
        var validator = new GetBookDetailQueryCommandValidator();
        var validationResult = validator.ValidateAsync(new BookDto() { Title = request.title, Author = request.author, Publisher = new Publisher.Queries.GetAllPublishers.PublisherDto() { PublisherName = request.publisher } });

        if (validationResult.Result.Errors.Any())
            throw new BadRequestException("Invalid Search request", validationResult);

        // Query the database
        var books = await _bookRepository.GetAsync(request.title, request.author, request.publisher);

        // convert data objects to DTO objects
        var data = _mapper.Map<List<BookDto>>(books);

        // return list of DTO object
        _logger.LogInformation("Books were retrieved successfully");
        return data;
    }
}
