﻿using BookStore.Application.Features.Publisher.Queries.GetAllPublishers;
using MediatR;

namespace BookStore.Application.Features.Publisher.Queries.GetAllPublishers;

public record GetPublishersQuery(string publisher) : IRequest<PublisherDto>;
