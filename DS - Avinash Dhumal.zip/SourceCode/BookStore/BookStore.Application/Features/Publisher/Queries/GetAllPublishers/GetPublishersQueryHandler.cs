﻿using AutoMapper;
using BookStore.Application.Contracts.Logging;
using BookStore.Application.Contracts.Persistence;
using BookStore.Application.Features.Publisher.Queries.GetAllPublishers;
using MediatR;

namespace BookStore.Application.Features.Publisher.Queries.GetAllPublishers;

public class GetPublishersQueryHandler : IRequestHandler<GetPublishersQuery, PublisherDto>
{
    private readonly IMapper _mapper;
    private readonly IPublisherRepository _publisherRepository;
    private readonly IAppLogger<GetPublishersQueryHandler> _logger;

    public GetPublishersQueryHandler(IMapper mapper, IPublisherRepository publisherRepository, IAppLogger<GetPublishersQueryHandler> logger)
    {
        this._mapper = mapper;
        this._publisherRepository = publisherRepository;
        this._logger = logger;
    }

    public async Task<PublisherDto> Handle(GetPublishersQuery request, CancellationToken cancellationToken)
    {
        // Query the database
        var publishers = await _publisherRepository.GetPublisherCatalogDetails(request.publisher);

        // convert data objects to DTO objects
        var data = _mapper.Map<PublisherDto>(publishers);

        // return list of DTO object
        _logger.LogInformation("Publishers were retrieved successfully");
        return data;
    }
}
