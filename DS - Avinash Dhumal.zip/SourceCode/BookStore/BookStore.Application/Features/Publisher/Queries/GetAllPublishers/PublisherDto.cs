﻿namespace BookStore.Application.Features.Publisher.Queries.GetAllPublishers;

public class PublisherDto
{
    public int Id { get; set; }
    public string PublisherName { get; set; }
    public string CatalogURL { get; set; }
    public string SearchPage { get; set; }
}
