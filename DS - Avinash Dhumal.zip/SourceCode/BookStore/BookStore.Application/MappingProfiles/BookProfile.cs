﻿using AutoMapper;
using BookStore.Application.Features.Book.Queries.GetAllBooksQuery;
using BookStore.Domain;

namespace BookStore.Application.MappingProfiles;

public class BookProfile : Profile
{
    public BookProfile()
    {
        CreateMap<BookDto, Book>().ReverseMap();
        CreateMap<Book, BookDto>();
    }
}
