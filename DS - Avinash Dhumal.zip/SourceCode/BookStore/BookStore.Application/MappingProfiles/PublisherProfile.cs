﻿using AutoMapper;
using BookStore.Application.Features.Publisher.Queries.GetAllPublishers;
using BookStore.Domain;

namespace BookStore.Application.MappingProfiles;

public class PublisherProfile : Profile
{
    public PublisherProfile()
    {
        CreateMap<PublisherDto, Publisher>().ReverseMap();
        CreateMap<Publisher, PublisherDto>();
    }
}
