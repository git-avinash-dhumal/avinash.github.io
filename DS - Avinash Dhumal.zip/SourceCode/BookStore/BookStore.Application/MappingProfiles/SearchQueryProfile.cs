﻿using AutoMapper;
using BookStore.Application.Features.Book.Commands.SearchQuery.SaveSearchQuery;
using BookStore.Domain;

namespace BookStore.Application.MappingProfiles;

public class SearchQueryProfile : Profile
{
    public SearchQueryProfile()
    {
        CreateMap<SaveSearchQueryCommand, SearchQuery>().ReverseMap();
    }
}
