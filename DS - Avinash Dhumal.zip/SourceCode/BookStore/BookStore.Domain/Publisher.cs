﻿using BookStore.Common;

namespace BookStore.Domain;

public class Publisher: BaseEntity
{ 
    public string PublisherName { get; set; }
    public string CatalogURL { get; set; }
    public string SearchPage { get; set; }
}