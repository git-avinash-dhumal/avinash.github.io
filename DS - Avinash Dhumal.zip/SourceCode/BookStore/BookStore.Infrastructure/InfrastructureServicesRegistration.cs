﻿using BookStore.Application.Contracts.Email;
using BookStore.Application.Contracts.Logging;
using BookStore.Application.Contracts.PublisherCatalogService;
using BookStore.Application.Models.Email;
using BookStore.Infrastructure.EmailService;
using BookStore.Infrastructure.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using BookStore.Infrastructure.PublisherCatalogServiceClient;

namespace BookStore.Infrastructure;

public static class InfrastructureServicesRegistration
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<EmailSettings>(configuration.GetSection("EmailSettings"));
        services.AddTransient<IEmailSender, EmailSender>();
        services.AddTransient<IPublisherCatalogService, PublisherCatalogService>();
        services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));
        return services;
    }
}