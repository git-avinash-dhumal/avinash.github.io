﻿using BookStore.Application.Contracts.PublisherCatalogService;
using BookStore.Application.Exceptions;
using System.Text.Encodings.Web;
using System.Web;

namespace BookStore.Infrastructure.PublisherCatalogServiceClient;

public class PublisherCatalogService : IPublisherCatalogService
{
    private static readonly HttpClient client = new HttpClient();

    public PublisherCatalogService()
    {

    }

    public async Task<string> GetPublisherCatalogByTitleOrAuthor(string title, string author, string catalogURL)
    {
        catalogURL = catalogURL.Replace("{title}", !string.IsNullOrEmpty(title) ? "title=" + HttpUtility.UrlEncode(title) : "");
        catalogURL = catalogURL.Replace("{author}", !string.IsNullOrEmpty(title) ? "&" + "author=" + HttpUtility.UrlEncode(author) : "" + "author=" + HttpUtility.UrlEncode(author));

        var response = await client.GetAsync(catalogURL);

        if (!response.IsSuccessStatusCode)
            throw new NotFoundException(nameof(String), catalogURL);

        return await response.Content.ReadAsStringAsync();
    }
}
