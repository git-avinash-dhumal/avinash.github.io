﻿using BookStore.Common;
using BookStore.Domain;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BookStore.Persistence.DatabaseContext;

public class BookStoreDatabaseContext : DbContext
{
    public BookStoreDatabaseContext(DbContextOptions<BookStoreDatabaseContext> options) : base(options)
    {
        
    }

    public DbSet<Book> Book { get; set; }
    public DbSet<Publisher> Publisher { get; set; }
    public DbSet<SearchQuery> SearchQuery { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(BookStoreDatabaseContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in base.ChangeTracker.Entries<BaseEntity>()
            .Where(q => q.State == EntityState.Added || q.State == EntityState.Modified))
        {
            entry.Entity.UpdatedDate = DateTime.Now;

            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedDate = DateTime.Now;
            }
        }

        return base.SaveChangesAsync(cancellationToken);
    }

}
