﻿using BookStore.Application.Contracts.Persistence;
using BookStore.Persistence.DatabaseContext;
using BookStore.Persistence.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BookStore.Persistence;

public static class PersistenceServiceRegistration
{
    public static IServiceCollection AddPersistenceServices(this IServiceCollection services,
        IConfiguration configuration)
    {
        //services.AddDbContext<BookStoreDatabaseContext>(options => {
        //    options.UseSqlServer(configuration.GetConnectionString("BookStoreDatabaseConnectionString"));
        //});

        services.AddDbContext<BookStoreDatabaseContext>(options =>
        {
            options.UseJet(configuration.GetConnectionString("BookStoreDatabaseConnectionString"));
        });

        services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
        services.AddScoped<IBookRepository, BookRepository>();
        services.AddScoped<IPublisherRepository, PublisherRepository>();
        services.AddScoped<ISearchQueryRepository, SearchQueryRepository>();

        return services;
    }
}
