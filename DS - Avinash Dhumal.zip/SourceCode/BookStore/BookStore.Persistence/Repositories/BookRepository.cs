﻿using BookStore.Application.Contracts.Persistence;
using BookStore.Domain;
using BookStore.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Persistence.Repositories;

public class BookRepository : GenericRepository<Book>, IBookRepository
{
    public BookRepository(BookStoreDatabaseContext context) : base(context)
    {

    }

    public async Task<List<Book>> GetAsync(string title, string author, string publisher)
    {
        var books = await _context.Book
                            .Where(w => w.Title.Contains(title) || w.Author.Contains(author))
                            .Include(q => q.Publisher)
                            .ToListAsync();

        return books;
    }
}
