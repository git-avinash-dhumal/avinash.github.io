﻿using BookStore.Application.Contracts.Persistence;
using BookStore.Application.Exceptions;
using BookStore.Domain;
using BookStore.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Persistence.Repositories;

public class PublisherRepository : GenericRepository<Publisher>, IPublisherRepository
{
    public PublisherRepository(BookStoreDatabaseContext context) : base(context)
    {
    }

    public async Task<Publisher> GetPublisherCatalogDetails(string publisher)
    {
        var publishers = await _context.Publisher.Where(w => w.PublisherName.Contains(publisher)).FirstOrDefaultAsync();

        if (publishers is null)
            throw new NotFoundException(nameof(Publisher), publisher);
        
        return publishers;
    }

    public async Task<bool> IsPublisherUnique(string name)
    {
        //return await _context.Publisher.AnyAsync(q => q.PublisherName == name) == false;
        return false;
    }
}
