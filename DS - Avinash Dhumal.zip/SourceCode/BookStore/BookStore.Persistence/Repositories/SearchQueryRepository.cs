﻿using BookStore.Application.Contracts.Persistence;
using BookStore.Domain;
using BookStore.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Persistence.Repositories;

public class SearchQueryRepository : GenericRepository<SearchQuery>, ISearchQueryRepository
{
    public SearchQueryRepository(BookStoreDatabaseContext context) : base(context)
    {

    }
}